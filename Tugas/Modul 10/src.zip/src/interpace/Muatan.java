package interpace;

public interface Muatan {
    double kapasitasMuatan();
}