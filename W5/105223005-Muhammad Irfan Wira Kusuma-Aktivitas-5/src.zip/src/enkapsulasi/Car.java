package enkapsulasi;

public class Car {
    String pemilik;
    private String merk;
    public int kapasitas;
    protected int jumlahBan;

}
