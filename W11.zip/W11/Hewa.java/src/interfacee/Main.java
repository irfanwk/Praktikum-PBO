package interfacee;

public class Main {
    public static void main(String[] args) {
        Kendaraan mobil = new Mobil();
        mobil.nyalakanMesin();
        mobil.matikanMesin();

    }
}
